"""CampusComp AI teaching starter."""
